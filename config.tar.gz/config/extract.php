<?php return array (
  'usdt_tip' => '6',
  'iuic_tip' => '6',
  'register_mobile_switch' => '0',
  'user_auth_switch' => '0',
);