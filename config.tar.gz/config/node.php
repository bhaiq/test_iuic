<?php return array (
  'small_node' => '0',
  'big_node' => '0',
  'super_node' => '0',
);