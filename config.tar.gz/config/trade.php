<?php return array (
  'tip_bl' => '0.005',
  'tip_bonus_bl' => '0.005',
  'cc_min_time' => '03:00:00',
  'cc_max_time' => '23:59:59',
  'lc_min_time' => '03:00:00',
  'lc_max_time' => '23:59:59',
  'today_trade_max_bl' => '1',
  'today_trade_min_bl' => '1',
  'cur_trade_max_bl' => '1',
  'cur_trade_min_bl' => '1',
  'trade_release_min_time' => '09:00:00',
  'trade_release_max_time' => '11:59:59',
);