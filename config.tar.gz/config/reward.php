<?php return array (
  'auth_reward' => '50',
);