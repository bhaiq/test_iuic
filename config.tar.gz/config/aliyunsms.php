<?php

return [
    'access_key'        => 'LTAIg78qm6EvjaAq', // accessKey
    'access_secret'     => 'bbvhgInXYToGy0AQ4X24R9aATUAOW3', // accessSecret
    'sign_name'         => '吉道了', // 签名
    'template'          => 'SMS_168820004'
];