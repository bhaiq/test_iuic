<?php return array (
  'coin_name' => 'USDT',
  'coin_type' => '0',
  'coin_num' => '1000',
);