<?php return array (
  'pid_reward' => '0',
  'admin_bonus_num' => '100000',
  'bonus_bl' => '00',
  'admin_bonus_bl' => '0',
  'energy_cny' => '1',
  'energy_exchange_tip' => '0',
);