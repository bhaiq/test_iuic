<?php return array (
  'robot_switch' => '0',
  'robot_start_time' => '11:11:11',
  'robot_end_time' => '23:59:59',
  'robot_min_range' => '0.01',
  'robot_max_range' => '0.04',
  'robot_trade_status' => '0',
  'robot_max_price' => '0.22',
  'robot_min_price' => '0.1950',
  'robot_min_trade_num' => '100',
  'robot_max_trade_num' => '200',
);