<?php return array (
  'recommend_share_bl' => '0.1',
  'recommend_partner_bl' => '0.05',
);