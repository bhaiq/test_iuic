<?php return array (
  'trade_bl' => '0',
  'today_release_bl' => '0',
  'today_release_count' => '0',
  'today_release_num' => '0',
  'kuangchi_static_release_bl' => '0',
);