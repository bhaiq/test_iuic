<?php return array (
  'cost' => '7200',
  'count' => '50',
  'tip_partner' => '0.1',
  'recommend_all_first_bl' => '0',
);