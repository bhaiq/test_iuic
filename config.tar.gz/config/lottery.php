<?php return array (
  'lottery_one_num' => '1',
);